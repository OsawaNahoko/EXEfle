using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;//カウントダウンに使用


[RequireComponent(typeof(Rigidbody))]

public class playerController : MonoBehaviour
{   
    public float CountDownTime;    // カウントダウンタイム
    public float speed = 10;
    public float LimitSpeed;
    public float deceleration = 2f; // 減速度
    public int invisibleTime = 60;//無敵時間
    public int restInvisibleTime = 0;//残り無敵時間
      
    public static bool Clearcheck = false;
    private bool isMoving = false;

    public GameObject clearLabelObject;
    public GameObject TaimeCountText;
    public GameObject GameOverObject;
    public GameObject ExitButton;
    public Text TextCountDown; 
    private Rigidbody rigidbody;
    public Animator Anime;
    
    void Start()
    {   
 
        // 同一のGameObjectが持つRigidbodyコンポーネントを取得
        rigidbody = GetComponent<Rigidbody>();
        restInvisibleTime = 0;//残り無敵時間
    }

    void Update()
    {
        //無敵時間の減少
        if(this.restInvisibleTime > 0)
        this.restInvisibleTime--;

        // カウントダウンタイムを整形して表示
        TextCountDown.text = String.Format("{0:00}", CountDownTime);

        // 経過時刻を引いていく
        CountDownTime -= Time.deltaTime;

        if (CountDownTime <= 0.9F)
        {
            // 0.0秒以下になったらカウントダウンタイムを0.0で固定（止まったように見せる）
            CountDownTime = 0.0F;
            GameOverObject.SetActive(true);
            TaimeCountText.SetActive(false);
            //スクリプトを無効化しています。
            //（オブジェクト名）に付いている（スクリプト名）を消します。
            Ristatowall Ristato = GameObject.Find("ReStato").GetComponent<Ristatowall>();
            Destroy(Ristato);
            playerController player = GameObject.Find("player_6_15").GetComponent<playerController>();
            player.enabled = false;
         
        }


        // キーを離したら移動フラグをオフにする
        if (Input.GetKeyUp(KeyCode.LeftArrow) || Input.GetKeyUp(KeyCode.RightArrow) ||
            Input.GetKeyUp(KeyCode.A) || Input.GetKeyUp(KeyCode.D))
        {
            isMoving = false;
        }
    }

    void FixedUpdate()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        
        rigidbody.AddForce(x * speed, 0, z * speed);

        if (rigidbody.velocity.magnitude > LimitSpeed)
        {
            rigidbody.velocity = rigidbody.velocity.normalized * LimitSpeed;
        }
        if (!isMoving)
        {
            // キーを離した後は徐々に減速する力を加える
            rigidbody.velocity -= rigidbody.velocity * deceleration * Time.deltaTime;
        }
    }
     public void OnCollisionEnter(Collision collision)
    {
        // 当たったもののタグがclearの場合
        if (collision.gameObject.tag == "Clear")
        {
            Clearcheck = true;
            clearLabelObject.SetActive(true);
            TaimeCountText.SetActive(false);
        }

        if (collision.gameObject.tag == "DengerWell" && this.restInvisibleTime <= 0)
        {
            Anime.SetBool("Damage_anime", true);
            CountDownTime -= 5f;
            Invoke("Anime_Damege", 1.0f);
        }

         if (collision.gameObject.tag == "DengerZimen")
        {
            Anime.SetBool("Damage_anime", true);
            CountDownTime -= 30f;
            Invoke("Anime_Damege", 1.0f);
        }
    }

    void Anime_Damege()
    {
        Anime.SetBool("Damage_anime", false);
    }

}