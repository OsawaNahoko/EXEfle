using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TO_START : MonoBehaviour
{
   private float step_time;    // 経過時間カウント用

    // Start is called before the first frame update
    void Start()
    {
     step_time = 0.0f;  

    }

    // Update is called once per frame
    void Update()
    {
        Debug.Log(step_time);
         // 経過時間をカウント
        step_time += Time.deltaTime;
 
        // 3秒後に画面遷移（Gamesceneへ移動）
        if (step_time >= 31.0f )
        {
            SceneManager.LoadScene("Stato_Scens_2");
        }
    }
}
