using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;//カウントダウンに使用

public class GameController : MonoBehaviour
{

    
    public GameObject GameOverObject;
    public GameObject player;

    void Start () 
    {
        playerController.Clearcheck = false;
    }
     
    void Update () {
        
        if(playerController.Clearcheck == true)
        {
            player.SetActive(false);
            Ristatowall Ristato = GameObject.Find("ReStato").GetComponent<Ristatowall>();
            Destroy(Ristato);
            //Rigidbody rigt = GameObject.Find("player_6_15").GetComponent<Rigidbody>();
            //rigt.enabled = false;
            playerController.Clearcheck = false;
        }
    }

 
    public void OP()
    {
         SceneManager.LoadScene("OP");
    }
       public void STARTmovie_2()
    {
        SceneManager.LoadScene("OP_2");
    }
    public void ED()
    {
         SceneManager.LoadScene("ED");
    }
    public void Game_1()
    {
        SceneManager.LoadScene("stag_1");
    }

    public void Game_2()
    {
        SceneManager.LoadScene("stag_2");
    }

    public void Game_3()
    {
        SceneManager.LoadScene("stag_3");
    }

    public void ReStartGame()
    {
        SceneManager.LoadScene("Stato_Scens_2");
    }
 

}
