using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IremScript : MonoBehaviour
{
	public static int WaterCount = 10;

	void OnTriggerEnter (Collider hit)
	{

		if (hit.CompareTag ("Player")) {

			 WaterCount += 10;

			Destroy(this.gameObject);
		}
	}
}
