using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
       public AudioSource everytime;
       private static bool isLoad = false;

       private void Awake() 
{
       if(isLoad)
       {
              Destroy(this.gameObject);
              return;
       }
       else
       {
              isLoad = true;
       }

       everytime = this.GetComponent<AudioSource>();
       DontDestroyOnLoad(everytime.gameObject);
	
 }
}
