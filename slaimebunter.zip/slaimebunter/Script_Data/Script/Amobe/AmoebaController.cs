using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmoebaController : MonoBehaviour
{
    private BoxCollider2D m_boxCollider;
    //初期位置
    private Vector3 m_intialPosition;
    
    // 踏まれた時のジャンプ倍率
    public float jumpPower = 0.5f;
    // 踏んだと判定するレイヤー
    public LayerMask whatIsPlayer;
    
    
    private void Awake()     
    {
        this.m_boxCollider = this.GetComponent<BoxCollider2D>(); 
        //初期位置を記憶
        this.m_intialPosition =
                    this.transform.position;    
    }
    void Update()
    {
         if (Input.GetKeyDown(KeyCode.Space))
        {
            m_boxCollider.enabled =false;
            Invoke("Invokecollider", 1.0f);
        }

    }
    // 何かが当たった時の処理
    private void OnCollisionEnter2D(Collision2D collision)     
    {
        if(collision.gameObject.tag == "Enemy")
        {
            Destroy (this.gameObject);
        }
        // 当たったものの Tag が Player の場合
        if(collision.gameObject.tag == "Player")          
        {
            // 自分の頭の真ん中部分の位置を取得
            Vector2 pos = this.transform.position;
            float enemyCenterX = 
                  pos.x + m_boxCollider.offset.x *
                  this.transform.lossyScale.x;
            float enemyTopY = pos.y +
                            (this.m_boxCollider.offset.y + 
                             this.m_boxCollider.size.y) * 
                             this.transform.lossyScale.y;
            Vector2 enemyTop =
                 new Vector2(enemyCenterX, enemyTopY);
            //当たったと判定する範囲の作成
            Vector2 collisionArea =
                 new Vector2(this.m_boxCollider.size.x *  
                             this.transform.lossyScale.x * 0.45f,  0.1f);
              // 頭の真ん中から当たり範囲内に指定レイヤーがある
            Collider2D collisionPlayer =
                 Physics2D.OverlapArea(
                                enemyTop+collisionArea,
                                enemyTop-collisionArea,
                                this.whatIsPlayer);
            //当たり範囲に指定レイヤーのものが入っていた場合
            if(collisionPlayer)
            {
                //PlayerControllerコンポーネントを取得

            PlayerContoller PlayerContoller= collisionPlayer.GetComponent<PlayerContoller>();
                if(PlayerContoller)
                {
                    //プレイヤーに敵を踏んだ時のジャンプ処理を実行
                    PlayerContoller.enemyJumpForce(this.jumpPower);
                    Debug.Log("踏んでるよ");
                }
                
                //頭を踏まれたので自身を破壊する
                Destroy(this.gameObject);
            }


            if(collision.gameObject.tag == "Destroy")          
            {
               Destroy(this.gameObject);
            }
        
    }
}
}
