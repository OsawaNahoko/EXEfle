using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Animator),typeof(Rigidbody2D),typeof(BoxCollider2D))]


public class PlayerContoller : MonoBehaviour
{   //コンポーネントを取得
    private BoxCollider2D m_boxCollider;
    private Rigidbody2D m_rigidbody;
    private Animator m_animator;
    private AudioSource m_audioSource;
    //ブンレツ体を取得
    public GameObject Amobea;

    //打てる状況か管理するフラグ
    private bool ShootFlag = true;
    //地面に設置しているかのフラグ
    private bool m_isGround = false;
    //初期位置
    private Vector3 m_inirialPosition;
    //移動速度
    public float moveSpeed = 5.0f;
    //ジャンプの強さ
    public float jumpPower = 400.0f;
    //地面だと判断するレイヤー
    public LayerMask whatIsGround;

    public float power = 1000f;
    //射出スピード
    public float AmobeaSpeed = 20f;
    //残り残機
    public static int life_Count = 3;
    //射出点管理
    public Transform spawnPoint;

    [SerializeField]
    AudioClip[] Playeraudio;

    //0がブンレツ音　1がノーマルジャンプ音　2がブンレツ体を踏んだジャンプ音　3がダメージ音　4がコインゲット音


    //スクリプトのインスタンスがロードされたときに呼ばれる
private void Awake()
    {   //コンポーネントを取得
        this.m_audioSource =this.GetComponent<AudioSource>();
        this.m_boxCollider = this.GetComponent<BoxCollider2D>();
        this.m_rigidbody   = this.GetComponent<Rigidbody2D>();
        this.m_animator    = this.GetComponent<Animator>();
        //初期位置の記録
        this.m_inirialPosition = this.transform.position;
    }

void SetAudio(int PlayNumber)
    {
        m_audioSource.PlayOneShot(Playeraudio[PlayNumber]);
    }

    // Update is called once per frame
private void Update()
    {   //LeftShiftが押されたら移動スピードを二倍にしています。
        float x = Input.GetAxis("Horizontal");
        if(Input.GetKey(KeyCode.LeftShift))
        {
             x = x * 2; 
        }
        //ジャンプの入力があったか確認
        bool isJump = Input.GetButtonDown("Jump");
        this.Move(x,isJump);
        
        if(Input.GetButtonDown("Fire1") && m_isGround == false && ShootFlag == true )
        {
            Shoot();
            //サウンドを流しています。ブンレツ音
            SetAudio(0);
        }   
    }

void Move(float speedX,bool isJump)
    {
        //移動関連の処理
        if(Mathf.Abs(speedX) > 0)
        {
            Vector3 tmpEuler = this.transform.eulerAngles;
            if(Mathf.Sign(speedX) > 0)
            {
                tmpEuler.y = 0;
            }
            else
            {
                tmpEuler.y = 180;
            }
            this.transform.eulerAngles = tmpEuler;
        }

        this.m_rigidbody.velocity = new Vector2(speedX * this.moveSpeed,this.m_rigidbody.velocity.y);
        this.m_animator.SetFloat("InputX",Mathf.Abs(speedX));
        if(this.m_isGround && isJump)
        {
            //サウンドを流しています。ノーマルジャンプ
            SetAudio(1);
            this.m_rigidbody.AddForce(Vector2.up * this.jumpPower);
        }
        this.m_animator.SetFloat("Vertical",this.m_rigidbody.velocity.y);  
    }


//固定フレームレートで呼ばれる更新処理
private void FixedUpdate()
    {
        //位置を取得
        Vector2 pos =this.transform.position;

        //足元の座標を計算している
        //キャラクターの足元の位置を計算
        float characterBotton = pos.y + (this.m_boxCollider.offset.y - (this.m_boxCollider.size.y * 0.5f)) * this.transform.lossyScale.y;
        Vector2 groundCheck = new Vector2(pos.x,characterBotton);
        //地面との判定エリアの大きさ
                Vector2 froundArea =new Vector2(this.m_boxCollider.size.x * 0.49f,0.05f);

       //地面と設置しているかのチェック
       //第一引数が右上、第二引数が左下の指定範囲、第三引数の指定のレイヤーが範囲内に入っているかを返す
       this.m_isGround =
       Physics2D.OverlapArea(

            groundCheck + froundArea,//①
            groundCheck - froundArea,//②
            this.whatIsGround

       ); 
    this.m_animator.SetBool("IsGround",this.m_isGround);
    }

public void enemyJumpForce(float power)
    {
    //Yの速さを0にする
    Vector3 tmpVelocity = this.m_rigidbody.velocity;
    tmpVelocity.y = 0;
    this.m_rigidbody.velocity = tmpVelocity;
    //サウンドを流しています。ブンレツ体ジャンプ音
    SetAudio(2);

    //踏んだ時にJumpボタンが押されている場合
    if(Input.GetButton("Jump"))
    {
        //普通のジャンプ力を適応
        this.m_rigidbody.AddForce(new Vector2(0,this.jumpPower));

    }
    else
    {
        //普通のジャンプ力に引数の倍率をかける
        this.m_rigidbody.AddForce(new Vector2(0,this.jumpPower * power));
    }
  }

private void OnCollisionEnter2D(Collision2D collision){

        //Enemyに衝突した際の処理
        if(collision.gameObject.tag == "Enemy")
        {
                //サウンドを流しています　ダメージ
                SetAudio(3);
                StartCoroutine("Animetion_1");
                //魂の数をコンソールに流しています。
                Debug.Log(life_Count);
        }
        
        //Coinに衝突した際の処理
        if(collision.gameObject.tag == "Coin")
        {
            //サウンドを流しています。コインの音
                SetAudio(4);
        }
    }

public void Initialize()
    {
        //初期位置に戻す
        this.transform.position = this.m_inirialPosition;
    }

    //射出処理
void Shoot()
    {
        GameObject bullet = Instantiate(Amobea,spawnPoint.position,Quaternion.identity);
        Rigidbody2D rd = bullet.GetComponent<Rigidbody2D>();
        rd.velocity = Vector2.down * AmobeaSpeed;
    }

      IEnumerator Animetion_1()
    {   
         // メインカメラを取得
    Camera mainCamera = Camera.main;

    if (mainCamera)
    {
        //撃てなくしています
        ShootFlag = false;

        // ダメージモーションを再生
        this.m_animator.SetBool("IsDamege", true);

        // リジットボディタイプを変更　その場に固定する
        this.m_rigidbody.bodyType = RigidbodyType2D.Static;

        // 1秒停止
        yield return new WaitForSeconds(1.5f);

        // ダメージモーションから変更
        this.m_animator.SetBool("IsDamege", false);

        // lifeを１減らす
        life_Count--;

        Initialize();

        // リジットボディタイプを変更　動けるようになる
        this.m_rigidbody.bodyType = RigidbodyType2D.Dynamic;

        //撃てるように変更
        ShootFlag = true;

        // CameraController を取得
        GameCameraController cameraController = mainCamera.GetComponent<GameCameraController>();
        //カメラの初期化
        cameraController.Initialize();
    }

    }
    
}
