using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameCoinController : MonoBehaviour
{
    private BoxCollider2D m_boxCollider;
    //初期位置
    private Vector3 m_inialPosition;


    private void Awake()
    {
        this.m_boxCollider = this.GetComponent<BoxCollider2D>();
        //初期位置の記録
        this.m_inialPosition = this.transform.position;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Player")
        {
            this.gameObject.SetActive(false);
            
        }
    }
    //初期化処理
    public void Initialize()
    {
        //初期位置に戻す
        this.transform.position = this.m_inialPosition;
        //アクティブに戻す
        this.gameObject.SetActive(true);
    }
}
