using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartBlockclController : MonoBehaviour
{
    private BoxCollider2D m_boxCollider;
    
    //当たり判定で使うレイヤーの設定
    public LayerMask whatIsPlayer;

    private void Awake()
    {
        this.m_boxCollider =
                this.GetComponent<BoxCollider2D>();
    }

    //何かが当たった時に呼ばれる処理
    private void OnCollisionEnter2D(Collision2D collision)
    {
        //当たったものの　Tag が　Player　の場合
        if(collision.gameObject.tag == "Player")
        {
            //中心の位置を取得

            Vector2 pos = this.transform.position;
            //コリジョンの下側の位置を計算
            Vector2 groundCheck = 
            new Vector2(pos.x,pos.y -(this.m_boxCollider.size.y * 0.5f) * this.transform.lossyScale.y);

            //当たりの範囲
            Vector2 groundArea =
            new Vector2(this.m_boxCollider.size.x * this.transform.lossyScale.x * 0.45f,0.1f);

            //whatsPlayerのレイヤーが下側に当たっているか調べる
            Collider2D col2D =
            Physics2D.OverlapArea(groundCheck + groundArea,groundCheck - groundArea,
            this.whatIsPlayer);
            //下からのPlayerが当たった場合
            if(col2D)
            {
                //Gameシーンに移動する
                SceneManager.LoadScene("Game");
            }
        }
    }
}