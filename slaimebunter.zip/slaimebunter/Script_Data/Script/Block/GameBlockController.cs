using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameBlockController : MonoBehaviour
{
    private BoxCollider2D m_boxCollider;

//初期位置
private Vector3 m_inialPosition;

//当たったら壊れる判定に使うレイヤーの設定
    public LayerMask whatIsPlayer;
    //壊せるブロックかのフラグ
    public bool canBreak = false;


    private void Awake()
    {
        this.m_boxCollider = this.GetComponent<BoxCollider2D>();
        //初期位置を記録
        this.m_inialPosition =
                            this.transform.position;
    }

    //何かが当たった時に呼ばれる処理
    private void OnCollisionEnter2D(Collision2D collision)
    {
        //壊れないブロックなら戻る
        if(this.canBreak == false) return;
        //当たったののTag が　Player の場合
        if(collision.gameObject.tag == "Player")
        {
            Debug.Log("当たっている");
            //中心の位置を取得
            Vector2 pos = this.transform.position;
            //ブロックの下側の位置算出
            float bottomY = pos.y -
            (this.m_boxCollider.size.y * 0.5f)
            * this.transform.lossyScale.y;
            //下側の位置を作成
            Vector2 blockBottom =
                        new Vector2(pos.x,bottomY);
            //当たり判定の作成
            Vector2 bottomCollisionArea =
            new Vector2(this.m_boxCollider.size.x * this.transform.lossyScale.x * 0.45f, 0.1f);
            //プレイヤーとブロックの下側が当たったか判定
            Collider2D colPlayer =
             Physics2D.OverlapArea(
                blockBottom + bottomCollisionArea,
                blockBottom - bottomCollisionArea,
                this.whatIsPlayer
             );

            //当たったならブロックを非表示にする
             if(colPlayer)
             {
                 Debug.Log("反応している");
                this.gameObject.SetActive(false);
                
             }
        }
     
    }

       //初期化関数
        public void Initialize()
        {
            //初期位置に戻す
            this.transform.position =
                            this.m_inialPosition;
            //オブジェクトをアクティブに戻す
            this.gameObject.SetActive(true);
        }
}
