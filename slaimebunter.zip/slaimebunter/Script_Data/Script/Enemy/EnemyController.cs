using UnityEngine;
using System.Collections;

public class EnemyController : MonoBehaviour
{

    
    private void Awake()     
    {

    }
    // 何かが当たった時の処理
    private void OnCollisionEnter2D(Collision2D collision)     
    {
        // 当たったものの Tag が Player の場合
        if(collision.gameObject.tag == "Player")          
        {
                //GameManager を探す
                GameManager gameManager = (GameManager)GameObject.FindObjectOfType(typeof(GameManager));
                //初期化する
                if(gameManager)
                    gameManager.PlayercameraInitialize();
                
        }
    }
        
}
