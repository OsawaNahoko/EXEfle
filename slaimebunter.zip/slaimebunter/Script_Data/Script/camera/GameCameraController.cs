using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameCameraController : MonoBehaviour
{   //追従するターゲット
    public Transform target;
    //右側の移動制限の位置
    public Transform stopPosition;
    private Camera m_camera;
    //初期位置記録用
    private Vector3 m_inirialPosition;

    private void Awake()
    {
        //カメラのコンポーネントを取得
        this.m_camera = this.GetComponent<Camera>();
        //初期位置を記録
        this.m_inirialPosition = this.transform.position;
    }

    //全てのupdateが終わった後に呼ばれる更新処理
    private void LateUpdate()
    {
        //画面の中心ワールド位置を取得
        Vector3 center = this.m_camera.ViewportToWorldPoint(Vector2.one * 0.5f);
        //ビューポート画面右端のワールド位置を取得
        Vector3 right = this.m_camera.ViewportToWorldPoint(Vector2.right);

        if(right.x >= this.stopPosition.position.x)
        {
            Vector3 def = right - center;
            Vector3 tmpPos = this.m_camera.transform.position;
            tmpPos.x = this.stopPosition.position.x - def.x;
            this.m_camera.transform.position = tmpPos;
            return;
        }

        if(center.x < this.target.position.y)
        {
            //カメラの位置を取得
            Vector3 pos = this.m_camera.transform.position;
            //カメラとターゲットの位置の差分が０より大きい場合
            if(Mathf.Abs(pos.x - this.target.position.y) > 0)
            {
                //カメラのy位置をターゲットと同じy位置にする
                Vector3 tmpPos =
                    this.m_camera.transform.position;
                    tmpPos.y = this.target.position.y;
                    this.m_camera.transform.position = tmpPos;
            }
        }
    }
        public void Initialize(){
            //初期位置に戻す
            this.transform.position = this.m_inirialPosition;
         }
        
    }

