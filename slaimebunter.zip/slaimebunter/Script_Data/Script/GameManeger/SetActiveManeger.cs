using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SetActiveManeger : MonoBehaviour
{
    public GameObject[] SetActiveObjects;
    // Life_Text;     //0
    // Life_PleyerObj;  //1
    // GameOverObject;  //2
    // ClearObject;     //3
    // PleyerObject;    //4
    // PauseObject;     //5

    bool Pause;

    void SetObjects(int SetObjectNumber,bool setbool)
    {
        SetActiveObjects[SetObjectNumber].SetActive(setbool);
    }
    public void GameInitialize_SetActiv()
    {
        SetObjects(4,true);
        SetObjects(1,true);
        SetObjects(2,false);
        SetObjects(3,false);
    }

    // Update is called once per frame
    void Update()
    {

        // int count = GameObject.FindGameObjectswithTag("coin").Length;
        Text score_text = SetActiveObjects[0].GetComponent<Text>();
        score_text.text = "x" + PlayerContoller.life_Count;

//ゲームオーバーの処理
           GameObject Player_obj = GameObject.Find("Player");
          if(Player_obj && PlayerContoller.life_Count == 0)
        {
            SetObjects(4,false);
            SetObjects(2,true);
        } 
//ポーズ画面に関して
        if(Input.GetKeyUp(KeyCode.LeftControl))
        {
            if(Pause == true)
            {
            Pause = false;
            SetObjects(5,true);
            SetObjects(4,false);
            SetObjects(1,false);
            }else

            if(Pause == false)
            {
            Pause = true;
            SetObjects(5,false);
            SetObjects(4,true);
            SetObjects(1,true);
            }
        }
    }
}
