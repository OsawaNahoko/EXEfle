using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManeger : MonoBehaviour
{
    public void GO_to_Stat()
    {
        Invoke("Setscene",0.4f);
    }   

    void Setscene()
    {
        PlayerContoller.life_Count = 3;
        SceneManager.LoadScene("Stat");
    }

}
