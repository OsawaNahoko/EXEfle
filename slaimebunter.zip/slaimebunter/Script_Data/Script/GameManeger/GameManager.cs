using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{   

    //各コントローラーを保持する配列
    private GameBlockController [] blocks;
    private GameCoinController  [] coins;
    //private EnemyController   [] enemies;
    
    void Awake()
    {   
        
        //シーンから各コントローラーを探して保持する
        this.blocks  = (GameBlockController[])GameObject.FindObjectsOfType(typeof(GameBlockController));
        this.coins   = (GameCoinController[]) GameObject.FindObjectsOfType(typeof(GameCoinController));
        /*this.enemies   = (EnemyController[])    GameObject.FindObjectsOfType(typeof(EnemyController));*/
    }

    //ゲーム初期化関数
    public void GameInitialize()
    {
        //プレイヤーのライフを回復しています。
        PlayerContoller.life_Count = 3;
 
        //シーンからからtag Player のオブジェクトを探す
        GameObject playerObj =
                    GameObject.FindGameObjectWithTag("Player");
        // プレイヤーから PlayerController を取得
        PlayerContoller player =         
                    playerObj.GetComponent<PlayerContoller>();
        // プレイヤーの初期化 
                 if(player)
                    player.Initialize();
        // シーンから tag が MainCamera のオブジェクトを取得
          Camera mainCamera = Camera.main;
          // CameraController を取得
          GameCameraController cameraController =    
                    mainCamera.GetComponent<GameCameraController>();
        // カメラの初期化
                  if(cameraController)
                                 cameraController.Initialize();
        // ブロックを初期化
         foreach(GameBlockController block in this.blocks)
               block.Initialize();
        // コインを初期化
        foreach(GameCoinController coin in this.coins)
                coin.Initialize();
       /* // 敵を初期化
        foreach(EnemyController enemy in this.enemies)
                 enemy.Initialize();*/
    }

    public void PlayercameraInitialize()
    {
        //シーンからからtag Player のオブジェクトを探す
        GameObject playerObj =
                    GameObject.FindGameObjectWithTag("Player");
        // プレイヤーから PlayerController を取得
        PlayerContoller player =         
                    playerObj.GetComponent<PlayerContoller>();
        // プレイヤーの初期化 
                 if(player)
                            player.Initialize();
        // シーンから tag が MainCamera のオブジェクトを取得
          Camera mainCamera = Camera.main;
          // CameraController を取得
          GameCameraController cameraController =    
                    mainCamera.GetComponent<GameCameraController>();
        // カメラの初期化
                  if(cameraController)
                                 cameraController.Initialize();
    }
   
}
